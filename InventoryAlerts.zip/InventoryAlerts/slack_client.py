"""
Thin wrapper around slack_sdk.WebClient for sending messages, alerts, and reports.
All outgoing messages go through this module so formatting stays consistent.
"""

import logging
from datetime import datetime
import pytz
from slack_sdk import WebClient
from slack_sdk.errors import SlackApiError
from config import Config

logger = logging.getLogger(__name__)

_client: WebClient | None = None


def get_client() -> WebClient:
    global _client
    if _client is None:
        _client = WebClient(token=Config.SLACK_BOT_TOKEN)
    return _client


# ── Low-level send ────────────────────────────────────────────────────────────

def send_message(channel: str, text: str, blocks: list | None = None) -> bool:
    """Post a message to *channel*. Returns True on success."""
    try:
        kwargs: dict = {"channel": channel, "text": text}
        if blocks:
            kwargs["blocks"] = blocks
        get_client().chat_postMessage(**kwargs)
        return True
    except SlackApiError as e:
        logger.error("Slack API error sending to %s: %s", channel, e.response["error"])
        return False
    except Exception as e:
        logger.error("Unexpected error sending Slack message: %s", e)
        return False


# ── Alert ─────────────────────────────────────────────────────────────────────

def send_low_inventory_alert(part_name: str, on_hand: int, threshold: int) -> None:
    """Send a :warning: alert when a part drops at or below its threshold."""
    text = (
        f":warning: *Low Inventory Alert*\n"
        f"Part:      `{part_name}`\n"
        f"On Hand:   *{on_hand}* unit(s)\n"
        f"Threshold: {threshold} unit(s)"
    )
    logger.info("Sending low-inventory alert for %s (on_hand=%d, threshold=%d)", part_name, on_hand, threshold)
    send_message(Config.SLACK_ALERT_CHANNEL, text)


def send_recovery_notice(part_name: str, on_hand: int, threshold: int) -> None:
    """Optional: notify when a previously-alerted part recovers above threshold."""
    text = (
        f":white_check_mark: *Inventory Recovered*\n"
        f"Part:      `{part_name}`\n"
        f"On Hand:   *{on_hand}* unit(s) (threshold: {threshold})"
    )
    send_message(Config.SLACK_ALERT_CHANNEL, text)


# ── Report ────────────────────────────────────────────────────────────────────

def send_inventory_report(
    inventory: dict[str, int],
    title: str = "Inventory Report",
    thresholds: dict | None = None,
    channel: str | None = None,
) -> None:
    """
    Post a formatted inventory table to Slack.

    If *thresholds* is supplied, parts at/below their threshold are flagged with :warning:.
    *channel* overrides Config.SLACK_ALERT_CHANNEL (useful for bot replies to the right thread).
    """
    target = channel or Config.SLACK_ALERT_CHANNEL

    tz = pytz.timezone(Config.REPORT_TIMEZONE)
    now_str = datetime.now(tz).strftime("%Y-%m-%d %I:%M %p %Z")

    if not inventory:
        send_message(target, f"*{title}*\n_{now_str}_\nNo monitored parts found in the database.")
        return

    thresholds = thresholds or {}
    prefix_thresh: dict = thresholds.get("prefix_thresholds", {})
    part_thresh: dict = thresholds.get("part_thresholds", {})

    def _threshold_for(name: str) -> int | None:
        if name in part_thresh:
            return part_thresh[name]
        for pfx, val in prefix_thresh.items():
            if name.upper().startswith(pfx.upper()):
                return val
        return None

    lines = []
    for part in sorted(inventory):
        qty = inventory[part]
        thresh = _threshold_for(part)
        flag = " ⚠️" if (thresh is not None and qty <= thresh) else ""
        lines.append(f"  {part:<22} {qty:>6} unit(s){flag}")

    body = "\n".join(lines)
    text = f"*{title}*\n_{now_str}_\n```\n{body}\n```"
    send_message(target, text)
