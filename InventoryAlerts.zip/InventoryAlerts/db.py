"""
Access database reader.

Inventory formula mirrors DHR.aspx.cs updateQty_Click exactly:

  on_hand = SUM(tblReceiving.QuantityReceived  WHERE PartNumber = <part_id>)
          - SUM(tblLotTracking.QuantityConverted
                  JOIN tblLots ON tblLots.LotIssue = tblLotTracking.LotIssue
                WHERE tblLotTracking.PartNumber = <part_id>)

Parts monitored are those whose PartNumber in tblSupplies matches the same
prefix rules used in DHR.aspx.cs rpItems_ItemDataBound / updateQty_Click.

Supplier 155 ("InSitu FIZ - Inventory Adjust") is included in QuantityReceived
totals (same as qtyTotal in the original code).
"""

import logging
import pyodbc
from config import Config

logger = logging.getLogger(__name__)

# ── Part-prefix filter ────────────────────────────────────────────────────────
# Mirrors the StartsWith checks in DHR.aspx.cs lines 523-524 and 960-961.
_SIMPLE_PREFIXES = ("19T", "19S", "19N", "22PM", "22C", "15H", "14C")


def is_monitored_part(part_name: str) -> bool:
    """Return True if this part belongs to the balloon/stent family we track."""
    if not part_name:
        return False
    p = part_name.upper()
    for prefix in _SIMPLE_PREFIXES:
        if p.startswith(prefix.upper()):
            return True
    if p.startswith("18"):
        return True
    # 17x parts are included UNLESS they end with "MM"
    if p.startswith("17") and not p.endswith("MM"):
        return True
    return False


# ── Connection ────────────────────────────────────────────────────────────────

def _get_connection() -> pyodbc.Connection:
    """
    Open a read-only ODBC connection to the MS Access .mdb file.
    Tries the 64-bit ACE driver first, then the legacy 32-bit Jet driver.
    The machine running QBApp already has at least one of these installed.
    """
    db_path = Config.ACCESS_DB_PATH
    drivers_to_try = [
        f"DRIVER={{Microsoft Access Driver (*.mdb, *.accdb)}};DBQ={db_path};",
        f"DRIVER={{Microsoft Access Driver (*.mdb)}};DBQ={db_path};",
        f"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={db_path};",
    ]
    last_err = None
    for conn_str in drivers_to_try:
        try:
            conn = pyodbc.connect(conn_str, readonly=True)
            logger.debug("Connected with: %s", conn_str.split(";")[0])
            return conn
        except pyodbc.Error as e:
            last_err = e
            continue
    raise ConnectionError(
        f"Could not connect to Access database at:\n  {db_path}\n"
        f"Last error: {last_err}\n"
        "Make sure the Microsoft Access Database Engine (ACE/Jet) is installed\n"
        "and that the .mdb file path is accessible from this machine."
    ) from last_err


# ── Core inventory query ──────────────────────────────────────────────────────

def get_all_inventory() -> dict[str, int]:
    """
    Return {part_name: on_hand_qty} for every monitored part found in tblSupplies.

    Raises ConnectionError if the database is unreachable.
    """
    conn = _get_connection()
    try:
        cursor = conn.cursor()

        # 1. Load all supplies so we can filter by part-name prefix in Python
        #    (Access/Jet doesn't support LIKE with dynamic prefix lists efficiently)
        cursor.execute("SELECT PartID, PartNumber FROM tblSupplies WHERE PartNumber IS NOT NULL")
        all_supplies = cursor.fetchall()

        monitored = [(int(row[0]), str(row[1])) for row in all_supplies if is_monitored_part(row[1])]
        logger.debug("Monitored parts found in tblSupplies: %d", len(monitored))

        inventory: dict[str, int] = {}

        for part_id, part_name in monitored:
            # ── Step 1: total received (all suppliers including adj. supplier 155) ──
            cursor.execute(
                "SELECT SUM(QuantityReceived) FROM tblReceiving "
                "WHERE PartNumber = ? AND QuantityReceived IS NOT NULL",
                part_id,
            )
            row = cursor.fetchone()
            qty_total: int = int(row[0]) if row[0] is not None else 0

            # ── Step 2: total converted (kitted) via tblLots JOIN tblLotTracking ──
            cursor.execute(
                "SELECT SUM(lt.QuantityConverted) "
                "FROM tblLots AS l "
                "INNER JOIN tblLotTracking AS lt ON l.LotIssue = lt.LotIssue "
                "WHERE lt.PartNumber = ? AND lt.QuantityConverted IS NOT NULL",
                part_id,
            )
            row = cursor.fetchone()
            total_converted: int = int(row[0]) if row[0] is not None else 0

            on_hand = qty_total - total_converted
            inventory[part_name] = on_hand
            logger.debug(
                "%s (id=%d): received=%d  converted=%d  on_hand=%d",
                part_name, part_id, qty_total, total_converted, on_hand,
            )

        return inventory

    finally:
        conn.close()


def get_part_inventory(part_name: str) -> int | None:
    """Return on-hand quantity for a single part, or None if not found."""
    inventory = get_all_inventory()
    return inventory.get(part_name)
