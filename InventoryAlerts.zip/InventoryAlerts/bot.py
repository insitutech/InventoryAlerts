"""
Slack bot — Socket Mode (no public URL required).

Recognised commands (sent as plain messages in any channel the bot is in,
or as direct messages to the bot):

  inventory              → full inventory report for all monitored parts
  inventory <part>       → inventory for parts whose name starts with <part>
                           e.g.  "inventory 19T"  or  "inventory 18M10"
  thresholds             → show currently configured thresholds
  help                   → show this command list

The bot only responds when the message STARTS WITH one of these keywords
(case-insensitive), so normal conversation in the channel is not interrupted.
"""

import logging
from slack_bolt import App
from slack_bolt.adapter.socket_mode import SocketModeHandler
from config import Config
from db import get_all_inventory

logger = logging.getLogger(__name__)

app = App(token=Config.SLACK_BOT_TOKEN)


# ── Helpers ───────────────────────────────────────────────────────────────────

def _format_inventory_table(inventory: dict[str, int], thresholds: dict) -> str:
    prefix_thresh: dict = thresholds.get("prefix_thresholds", {})
    part_thresh: dict = thresholds.get("part_thresholds", {})

    def _thresh(name: str):
        if name in part_thresh:
            return part_thresh[name]
        for pfx, val in prefix_thresh.items():
            if name.upper().startswith(pfx.upper()):
                return val
        return None

    lines = []
    for part in sorted(inventory):
        qty = inventory[part]
        t = _thresh(part)
        flag = " ⚠️ LOW" if (t is not None and qty <= t) else ""
        lines.append(f"  {part:<22} {qty:>6} unit(s){flag}")
    return "\n".join(lines)


# ── Message handlers ──────────────────────────────────────────────────────────

@app.message(r"(?i)^inventory\b")
def handle_inventory(message, say):
    text: str = message.get("text", "").strip()
    parts = text.split(None, 1)   # split on first whitespace
    query = parts[1].strip().upper() if len(parts) > 1 else ""

    try:
        thresholds = Config.load_thresholds()
        inventory = get_all_inventory()
    except ConnectionError as e:
        say(f":x: *Database unreachable.*\n```{e}```")
        return
    except Exception as e:
        say(f":x: *Error reading inventory.*\n```{e}```")
        return

    if query:
        # Filter to parts whose name starts with the query string
        filtered = {k: v for k, v in inventory.items() if k.upper().startswith(query)}
        if not filtered:
            say(f":mag: No monitored parts found matching `{query}`.")
            return
        title = f"Inventory — `{query}*`"
        table = _format_inventory_table(filtered, thresholds)
    else:
        if not inventory:
            say(":mag: No monitored parts found in the database.")
            return
        title = "Current Inventory — All Monitored Parts"
        table = _format_inventory_table(inventory, thresholds)

    say(f"*{title}*\n```\n{table}\n```")


@app.message(r"(?i)^thresholds?\b")
def handle_thresholds(message, say):
    try:
        thresholds = Config.load_thresholds()
    except Exception as e:
        say(f":x: Could not load thresholds.json\n```{e}```")
        return

    prefix_thresh: dict = thresholds.get("prefix_thresholds", {})
    part_thresh: dict = thresholds.get("part_thresholds", {})

    lines = ["*Configured Thresholds*", "", "*By prefix:*", "```"]
    for pfx, val in sorted(prefix_thresh.items()):
        lines.append(f"  {pfx + '*':<24} {val:>6} unit(s)")
    lines.append("```")

    if part_thresh:
        lines += ["*By exact part number:*", "```"]
        for part, val in sorted(part_thresh.items()):
            lines.append(f"  {part:<24} {val:>6} unit(s)")
        lines.append("```")
    else:
        lines.append("_(No part-specific overrides configured)_")

    say("\n".join(lines))


@app.message(r"(?i)^help\b")
def handle_help(message, say):
    say(
        "*Inventory Alert Bot — Commands*\n"
        "```\n"
        "  inventory              Full report for all monitored parts\n"
        "  inventory <prefix>     Filter by part name prefix (e.g. inventory 19T)\n"
        "  thresholds             Show alert thresholds from thresholds.json\n"
        "  help                   Show this message\n"
        "```\n"
        "_Alerts are sent automatically when on-hand quantity drops at or below "
        "a configured threshold. A weekly report is posted every Monday at 9 AM CST._"
    )


# ── Socket Mode entry-point ───────────────────────────────────────────────────

def start_bot() -> None:
    """Start the Socket Mode handler (blocks the calling thread)."""
    logger.info("Starting Slack bot via Socket Mode...")
    handler = SocketModeHandler(app, Config.SLACK_APP_TOKEN)
    handler.start()
